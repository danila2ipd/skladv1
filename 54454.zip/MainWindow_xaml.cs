using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ConstructionWarehouse
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _clock = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };

        public MainWindow()
        {
            InitializeComponent();

            _clock.Tick += (s, e) =>
                TxtDateTime.Text = DateTime.Now.ToString("dd MMMM yyyy, HH:mm:ss");
            _clock.Start();

            InitUserInfo();
            LoadDashboard();
        }

        // ── Инициализация блока пользователя ─────────────────────────────

        private void InitUserInfo()
        {
            if (Session.Current == null) return;

            // Аватар — первая буква имени
            string name = Session.Current.FullName ?? Session.Current.Login;
            TxtUserAvatar.Text = name.Length > 0 ? name[0].ToString().ToUpper() : "?";
            TxtUserName.Text = name;
            TxtUserRole.Text = Session.Current.Role;

            // В шапке
            TxtUserInfo.Text = Session.Current.FullName + "  ·  " + Session.Current.Role;

            // Кнопка «Пользователи» — только администратору
            BtnUsers.Visibility = Session.Current.IsAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Кнопка «Админ-панель» — только администратору
            BtnAdmin.Visibility = Session.Current.IsAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;
            SepAdmin.Visibility = Session.Current.IsAdmin
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Кнопка «Панель менеджера» — менеджеру и администратору
            bool isManager = Session.Current.Role == "Менеджер" || Session.Current.IsAdmin;
            BtnManager.Visibility  = isManager ? Visibility.Visible  : Visibility.Collapsed;
            SepManager.Visibility  = isManager ? Visibility.Visible  : Visibility.Collapsed;
        }

        // ── Выход из аккаунта ─────────────────────────────────────────────

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult res = MessageBox.Show(
                "Вы уверены, что хотите выйти из аккаунта?",
                "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (res != MessageBoxResult.Yes) return;

            _clock.Stop();
            Session.Current = null;

            // Открываем окно входа
            LoginWindow login = new LoginWindow();

            // Меняем режим — не закрывать приложение при закрытии MainWindow
            Application.Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;

            Close(); // закрываем главное окно

            bool? result = login.ShowDialog();

            if (result == true)
            {
                Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
                MainWindow main = new MainWindow();
                Application.Current.MainWindow = main;
                main.Show();
            }
            else
            {
                Application.Current.Shutdown();
            }
        }

        // ── Навигация ─────────────────────────────────────────────────────

        private void NavBtn_Checked(object sender, RoutedEventArgs e)
        {
            if (PageDash == null) return;

            HideAll();
            if (sender == BtnDash)
            {
                PageDash.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Дашборд";
                LoadDashboard();
            }
            else if (sender == BtnStock)
            {
                PageStock.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Остатки";
                LoadStock();
            }
            else if (sender == BtnOps)
            {
                PageOps.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Операции";
                LoadOps();
            }
            else if (sender == BtnMaterials)
            {
                PageMaterials.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Справочник материалов";
                LoadMaterials();
            }
            else if (sender == BtnSuppliers)
            {
                PageSuppliers.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Поставщики";
                LoadSuppliers();
            }
            else if (sender == BtnAlerts)
            {
                PageAlerts.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Уведомления";
                LoadAlerts();
            }
            else if (sender == BtnUsers)
            {
                PageUsers.Visibility = Visibility.Visible;
                TxtPageTitle.Text = "Пользователи";
                LoadUsers();
            }
        }

        private void HideAll()
        {
            if (PageDash != null) PageDash.Visibility = Visibility.Collapsed;
            if (PageStock != null) PageStock.Visibility = Visibility.Collapsed;
            if (PageOps != null) PageOps.Visibility = Visibility.Collapsed;
            if (PageMaterials != null) PageMaterials.Visibility = Visibility.Collapsed;
            if (PageSuppliers != null) PageSuppliers.Visibility = Visibility.Collapsed;
            if (PageAlerts != null) PageAlerts.Visibility = Visibility.Collapsed;
            if (PageUsers != null) PageUsers.Visibility = Visibility.Collapsed;
        }

        // ── Дашборд ───────────────────────────────────────────────────────

        private void LoadDashboard()
        {
            try
            {
                DataTable dt = DB.GetDashboardStats();
                if (dt.Rows.Count > 0)
                {
                    DataRow r = dt.Rows[0];
                    KpiTotal.Text = r["TotalMaterials"].ToString();
                    KpiLow.Text = r["LowStockCount"].ToString();
                    KpiProjects.Text = r["ActiveProjects"].ToString();
                    KpiOps.Text = r["TodayOps"].ToString();
                    KpiReceived.Text = string.Format("{0:N0} ₽", Convert.ToDecimal(r["MonthReceived"]));
                    KpiIssued.Text = string.Format("{0:N0} ₽", Convert.ToDecimal(r["MonthIssued"]));
                }
                GridLowStock.ItemsSource = DB.GetLowStock().DefaultView;
            }
            catch (Exception ex) { ShowError(ex); }
        }

        // ── Остатки ───────────────────────────────────────────────────────

        private void LoadStock(string filter = "")
        {
            try { GridStock.ItemsSource = DB.GetStockLevels(filter).DefaultView; }
            catch (Exception ex) { ShowError(ex); }
        }

        private void TxtStockSearch_TextChanged(object s, TextChangedEventArgs e)
            => LoadStock(TxtStockSearch.Text.Trim());

        private void RefreshStock_Click(object s, RoutedEventArgs e)
        {
            TxtStockSearch.Clear();
            LoadStock();
        }

        // ── Операции ─────────────────────────────────────────────────────

        private void LoadOps()
        {
            try
            {
                GridOps.ItemsSource = DB.GetTransactions(DpFrom.SelectedDate, DpTo.SelectedDate).DefaultView;
            }
            catch (Exception ex) { ShowError(ex); }
        }

        private void FilterOps(object s, SelectionChangedEventArgs e) => LoadOps();

        private void ResetOpsFilter_Click(object s, RoutedEventArgs e)
        {
            DpFrom.SelectedDate = null;
            DpTo.SelectedDate = null;
            LoadOps();
        }

        private void NewTransaction_Click(object s, RoutedEventArgs e)
        {
            TransactionWindow dlg = new TransactionWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadOps();
        }

        // ── Материалы ────────────────────────────────────────────────────

        private void LoadMaterials()
        {
            try { GridMaterials.ItemsSource = DB.GetMaterials().DefaultView; }
            catch (Exception ex) { ShowError(ex); }
        }

        private void AddMaterial_Click(object s, RoutedEventArgs e)
        {
            MaterialWindow dlg = new MaterialWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadMaterials();
        }

        private void EditMaterial_Click(object s, RoutedEventArgs e)
        {
            DataRowView row = GridMaterials.SelectedItem as DataRowView;
            if (row == null) { MsgInfo("Выберите материал для редактирования."); return; }
            MaterialWindow dlg = new MaterialWindow(row.Row);
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadMaterials();
        }

        private void DeleteMaterial_Click(object s, RoutedEventArgs e)
        {
            DataRowView row = GridMaterials.SelectedItem as DataRowView;
            if (row == null) { MsgInfo("Выберите материал для удаления."); return; }

            int id = Convert.ToInt32(row["MaterialID"]);
            string name = row["Name"].ToString();

            if (MessageBox.Show("Удалить материал «" + name + "»?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            try { DB.DeleteMaterial(id); LoadMaterials(); }
            catch (Exception ex) { ShowError(ex); }
        }

        // ── Поставщики ────────────────────────────────────────────────────

        private void LoadSuppliers()
        {
            try { GridSuppliers.ItemsSource = DB.GetAllSuppliers().DefaultView; }
            catch (Exception ex) { ShowError(ex); }
        }

        private void AddSupplier_Click(object s, RoutedEventArgs e)
        {
            SupplierWindow dlg = new SupplierWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadSuppliers();
        }

        private void EditSupplier_Click(object s, RoutedEventArgs e)
        {
            DataRowView row = GridSuppliers.SelectedItem as DataRowView;
            if (row == null) { MsgInfo("Выберите поставщика."); return; }
            SupplierWindow dlg = new SupplierWindow(row.Row);
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadSuppliers();
        }

        // ── Уведомления ───────────────────────────────────────────────────

        private void LoadAlerts()
        {
            try { GridAlerts.ItemsSource = DB.GetLowStock().DefaultView; }
            catch (Exception ex) { ShowError(ex); }
        }

        // ── Пользователи ──────────────────────────────────────────────────

        private void LoadUsers()
        {
            try { GridUsers.ItemsSource = DB.GetAllUsers().DefaultView; }
            catch (Exception ex) { ShowError(ex); }
        }

        private void AddUser_Click(object s, RoutedEventArgs e)
        {
            UserEditWindow dlg = new UserEditWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadUsers();
        }

        private void EditUser_Click(object s, RoutedEventArgs e)
        {
            DataRowView row = GridUsers.SelectedItem as DataRowView;
            if (row == null) { MsgInfo("Выберите пользователя."); return; }
            UserEditWindow dlg = new UserEditWindow(row.Row);
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) LoadUsers();
        }

        private void DeleteUser_Click(object s, RoutedEventArgs e)
        {
            DataRowView row = GridUsers.SelectedItem as DataRowView;
            if (row == null) { MsgInfo("Выберите пользователя."); return; }

            int id = Convert.ToInt32(row["UserID"]);
            string login = row["Login"].ToString();

            if (Session.Current != null && login == Session.Current.Login)
            { MsgInfo("Нельзя удалить текущего пользователя."); return; }

            if (MessageBox.Show("Удалить пользователя «" + login + "»?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

            try { DB.DeleteUser(id); LoadUsers(); }
            catch (Exception ex) { ShowError(ex); }
        }

        // ── Панель менеджера ──────────────────────────────────────────

        private void ManagerPanel_Click(object sender, RoutedEventArgs e)
        {
            if (Session.Current == null)
            {
                MsgInfo("Доступ запрещён.");
                return;
            }
            bool isManager = Session.Current.Role == "Менеджер" || Session.Current.IsAdmin;
            if (!isManager)
            {
                MsgInfo("Доступ запрещён. Требуются права менеджера или администратора.");
                return;
            }
            ManagerWindow mgr = new ManagerWindow();
            mgr.Owner = this;
            mgr.ShowDialog();
        }

        // ── Админ-панель ──────────────────────────────────────────────

        private void AdminPanel_Click(object sender, RoutedEventArgs e)
        {
            if (Session.Current == null || !Session.Current.IsAdmin)
            {
                MsgInfo("Доступ запрещён. Требуются права администратора.");
                return;
            }
            AdminWindow adm = new AdminWindow();
            adm.Owner = this;
            adm.ShowDialog();
        }

        // ── Хелперы ───────────────────────────────────────────────────────

        private static void ShowError(Exception ex)
            => MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

        private static void MsgInfo(string msg)
            => MessageBox.Show(msg, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
    }
}
