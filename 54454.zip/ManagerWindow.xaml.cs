using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;

// Word
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

// Excel
using ClosedXML.Excel;

namespace ConstructionWarehouse
{
    public partial class ManagerWindow : Window
    {
        private DataTable _allUsers;

        public ManagerWindow()
        {
            InitializeComponent();

            // Даты по умолчанию — текущий месяц
            DpFrom.SelectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DpTo.SelectedDate   = DateTime.Today;

            LoadUsers();
        }

        // ════════════════════════════════════════════════════════════
        //  Переключение вкладок
        // ════════════════════════════════════════════════════════════

        private void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PanelUsers == null) return;
            PanelUsers.Visibility   = Visibility.Collapsed;
            PanelReports.Visibility = Visibility.Collapsed;

            if (sender == TabUsers)
            {
                PanelUsers.Visibility = Visibility.Visible;
                LoadUsers();
            }
            else if (sender == TabReports)
            {
                PanelReports.Visibility = Visibility.Visible;
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // ════════════════════════════════════════════════════════════
        //  Загрузка и фильтрация пользователей
        // ════════════════════════════════════════════════════════════

        private void LoadUsers()
        {
            try
            {
                _allUsers = DB.GetAllUsers();
                ApplyFilter();
                UpdatePendingCount();
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ApplyFilter()
        {
            if (_allUsers == null) return;

            ComboBoxItem sel    = CbFilter.SelectedItem as ComboBoxItem;
            string       filter = sel?.Content?.ToString() ?? "Все";

            switch (filter)
            {
                case "Ожидают активации":
                    _allUsers.DefaultView.RowFilter = "IsActive = 0 OR IsActive = 'False'";
                    break;
                case "Активные":
                    _allUsers.DefaultView.RowFilter = "IsActive = 1 OR IsActive = 'True'";
                    break;
                case "Заблокированные":
                    _allUsers.DefaultView.RowFilter = "IsActive = 0 OR IsActive = 'False'";
                    break;
                default:
                    _allUsers.DefaultView.RowFilter = "";
                    break;
            }

            GridUsers.ItemsSource  = _allUsers.DefaultView;
            TxtUserStatus.Text     = "Записей: " + _allUsers.DefaultView.Count;
        }

        private void UpdatePendingCount()
        {
            if (_allUsers == null) return;
            _allUsers.DefaultView.RowFilter = "IsActive = 0 OR IsActive = 'False'";
            int pending = _allUsers.DefaultView.Count;
            _allUsers.DefaultView.RowFilter = "";

            TxtPendingCount.Text = pending > 0
                ? $"Ожидают активации: {pending} чел."
                : "Все пользователи активированы.";
        }

        private void Filter_Changed(object s, SelectionChangedEventArgs e) => ApplyFilter();

        private void Grid_SelectionChanged(object s, SelectionChangedEventArgs e)
        {
            DataRowView row = GridUsers.SelectedItem as DataRowView;
            if (row == null) return;
            TxtUserStatus.Text = row["FullName"] + "  (@" + row["Login"] + ")  ·  " + row["Role"];
        }

        // ════════════════════════════════════════════════════════════
        //  Активация пользователя
        // ════════════════════════════════════════════════════════════

        private void Activate_Click(object sender, RoutedEventArgs e)
        {
            DataRowView row = GridUsers.SelectedItem as DataRowView;
            if (row == null) { Info("Выберите пользователя для активации."); return; }

            string active = row["IsActive"].ToString();
            bool isActive = active == "1" || active.ToLower() == "true";

            if (isActive)
            {
                Info("Пользователь «" + row["Login"] + "» уже активен.");
                return;
            }

            string login = row["Login"].ToString();
            int    id    = Convert.ToInt32(row["UserID"]);

            if (MessageBox.Show(
                    $"Активировать пользователя «{login}»?\nОн получит доступ к системе.",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question)
                != MessageBoxResult.Yes) return;

            try
            {
                DB.Execute(
                    "UPDATE Users SET IsActive = 1 WHERE UserID = @id",
                    new SqlParameter("@id", id));

                LoadUsers();
                TxtUserStatus.Text = $"✔  Пользователь «{login}» успешно активирован.";
            }
            catch (Exception ex) { Err(ex); }
        }

        // ════════════════════════════════════════════════════════════
        //  Деактивация пользователя
        // ════════════════════════════════════════════════════════════

        private void Deactivate_Click(object sender, RoutedEventArgs e)
        {
            DataRowView row = GridUsers.SelectedItem as DataRowView;
            if (row == null) { Info("Выберите пользователя для деактивации."); return; }

            string active = row["IsActive"].ToString();
            bool isActive = active == "1" || active.ToLower() == "true";

            if (!isActive)
            {
                Info("Пользователь «" + row["Login"] + "» уже неактивен.");
                return;
            }

            string login = row["Login"].ToString();
            int    id    = Convert.ToInt32(row["UserID"]);

            // Нельзя заблокировать себя
            if (Session.Current != null && login == Session.Current.Login)
            { Info("Нельзя деактивировать собственную учётную запись."); return; }

            if (MessageBox.Show(
                    $"Деактивировать пользователя «{login}»?\nОн потеряет доступ к системе.",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning)
                != MessageBoxResult.Yes) return;

            try
            {
                DB.Execute(
                    "UPDATE Users SET IsActive = 0 WHERE UserID = @id",
                    new SqlParameter("@id", id));

                LoadUsers();
                TxtUserStatus.Text = $"🚫  Пользователь «{login}» деактивирован.";
            }
            catch (Exception ex) { Err(ex); }
        }

        // ════════════════════════════════════════════════════════════
        //  Отчёты — Word
        // ════════════════════════════════════════════════════════════

        private void ReportStockWord_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Остатки_склад", "docx");
            if (path == null) return;
            try
            {
                GenerateWord(path, "Отчёт по остаткам склада",
                    new[] { "Материал", "Категория", "Артикул", "Остаток", "Минимум", "Ед.", "Место", "Статус" },
                    new[] { "MaterialName", "Category", "ArticleNumber", "CurrentStock", "MinStock", "Unit", "Location", "StockStatus" },
                    DB.GetStockLevels());
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportOpsWord_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Журнал_операций", "docx");
            if (path == null) return;
            try
            {
                GenerateWord(path, "Журнал операций  " + FormatPeriod(),
                    new[] { "Дата", "Тип", "Материал", "Кол-во", "Ед.", "Цена", "Сумма", "Поставщик", "Объект", "Сотрудник" },
                    new[] { "TransactionDate", "TransactionType", "Material", "Quantity", "Unit", "UnitPrice", "TotalCost", "Supplier", "Project", "Employee" },
                    DB.GetTransactions(DpFrom.SelectedDate, DpTo.SelectedDate));
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportLowWord_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Низкий_запас", "docx");
            if (path == null) return;
            try
            {
                GenerateWord(path, "Материалы с низким остатком",
                    new[] { "Материал", "Категория", "Остаток", "Минимум", "Ед.", "Место" },
                    new[] { "MaterialName", "Category", "CurrentStock", "MinStock", "Unit", "Location" },
                    DB.GetLowStock());
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportSummaryWord_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Сводный_отчет", "docx");
            if (path == null) return;
            try { GenerateSummaryWord(path); ShowReportDone(path); }
            catch (Exception ex) { Err(ex); }
        }

        // ════════════════════════════════════════════════════════════
        //  Отчёты — Excel
        // ════════════════════════════════════════════════════════════

        private void ReportStockExcel_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Остатки_склад", "xlsx");
            if (path == null) return;
            try
            {
                GenerateExcel(path, "Остатки склада",
                    new[] { "Материал", "Категория", "Артикул", "Остаток", "Минимум", "Ед.", "Место", "Статус" },
                    new[] { "MaterialName", "Category", "ArticleNumber", "CurrentStock", "MinStock", "Unit", "Location", "StockStatus" },
                    DB.GetStockLevels());
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportOpsExcel_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Журнал_операций", "xlsx");
            if (path == null) return;
            try
            {
                GenerateExcel(path, "Журнал операций",
                    new[] { "Дата", "Тип", "Материал", "Кол-во", "Ед.", "Цена", "Сумма", "Поставщик", "Объект", "Сотрудник" },
                    new[] { "TransactionDate", "TransactionType", "Material", "Quantity", "Unit", "UnitPrice", "TotalCost", "Supplier", "Project", "Employee" },
                    DB.GetTransactions(DpFrom.SelectedDate, DpTo.SelectedDate));
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportLowExcel_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Низкий_запас", "xlsx");
            if (path == null) return;
            try
            {
                GenerateExcel(path, "Низкий запас",
                    new[] { "Материал", "Категория", "Остаток", "Минимум", "Ед.", "Место" },
                    new[] { "MaterialName", "Category", "CurrentStock", "MinStock", "Unit", "Location" },
                    DB.GetLowStock());
                ShowReportDone(path);
            }
            catch (Exception ex) { Err(ex); }
        }

        private void ReportSummaryExcel_Click(object s, RoutedEventArgs e)
        {
            string path = GetSavePath("Сводный_отчет", "xlsx");
            if (path == null) return;
            try { GenerateSummaryExcel(path); ShowReportDone(path); }
            catch (Exception ex) { Err(ex); }
        }

        // ════════════════════════════════════════════════════════════
        //  Генерация Word
        // ════════════════════════════════════════════════════════════

        private void GenerateWord(string path, string title,
            string[] headers, string[] fields, DataTable dt)
        {
            using (WordprocessingDocument doc =
                   WordprocessingDocument.Create(path, WordprocessingDocumentType.Document))
            {
                MainDocumentPart main = doc.AddMainDocumentPart();
                main.Document = new Document();
                Body body = main.Document.AppendChild(new Body());

                body.AppendChild(new Paragraph(
                    new ParagraphProperties(
                        new Justification { Val = JustificationValues.Center },
                        new SpacingBetweenLines { After = "200" }),
                    new Run(
                        new RunProperties(new Bold(), new FontSize { Val = "32" }, new Color { Val = "1B5E9E" }),
                        new Text(title))));

                body.AppendChild(new Paragraph(
                    new ParagraphProperties(
                        new Justification { Val = JustificationValues.Center },
                        new SpacingBetweenLines { After = "400" }),
                    new Run(
                        new RunProperties(new Color { Val = "888888" }, new FontSize { Val = "20" }),
                        new Text("Сформирован: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm") +
                                 "  ·  " + (Session.Current?.FullName ?? "")))));

                if (dt == null || dt.Rows.Count == 0)
                {
                    body.AppendChild(new Paragraph(new Run(new Text("Данных нет."))));
                    main.Document.Save();
                    return;
                }

                Table table = new Table();
                table.AppendChild(new TableProperties(
                    new TableBorders(
                        MkBorder<TopBorder>(), MkBorder<BottomBorder>(),
                        MkBorder<LeftBorder>(), MkBorder<RightBorder>(),
                        MkBorder<InsideHorizontalBorder>(), MkBorder<InsideVerticalBorder>()),
                    new TableWidth { Width = "9360", Type = TableWidthUnitValues.Dxa }));

                // Заголовок
                TableRow hdr = new TableRow();
                foreach (string h in headers)
                    hdr.AppendChild(new TableCell(
                        new TableCellProperties(
                            new Shading { Fill = "1B5E9E", Val = ShadingPatternValues.Clear },
                            new TableCellMargin(
                                new TopMargin    { Width = "80",  Type = TableWidthUnitValues.Dxa },
                                new BottomMargin { Width = "80",  Type = TableWidthUnitValues.Dxa },
                                new LeftMargin   { Width = "120", Type = TableWidthUnitValues.Dxa },
                                new RightMargin  { Width = "120", Type = TableWidthUnitValues.Dxa })),
                        new Paragraph(new Run(
                            new RunProperties(new Bold(), new Color { Val = "FFFFFF" }, new FontSize { Val = "20" }),
                            new Text(h)))));
                table.AppendChild(hdr);

                // Строки данных
                bool alt = false;
                foreach (DataRow row in dt.Rows)
                {
                    TableRow tr   = new TableRow();
                    string   fill = alt ? "F0F4FA" : "FFFFFF";
                    foreach (string f in fields)
                    {
                        string val = "";
                        if (dt.Columns.Contains(f))
                        {
                            object v = row[f];
                            val = (v is DateTime) ? ((DateTime)v).ToString("dd.MM.yyyy HH:mm")
                                                  : v == DBNull.Value ? "" : v.ToString();
                        }
                        tr.AppendChild(new TableCell(
                            new TableCellProperties(
                                new Shading { Fill = fill, Val = ShadingPatternValues.Clear },
                                new TableCellMargin(
                                    new TopMargin    { Width = "60",  Type = TableWidthUnitValues.Dxa },
                                    new BottomMargin { Width = "60",  Type = TableWidthUnitValues.Dxa },
                                    new LeftMargin   { Width = "120", Type = TableWidthUnitValues.Dxa },
                                    new RightMargin  { Width = "120", Type = TableWidthUnitValues.Dxa })),
                            new Paragraph(new Run(
                                new RunProperties(new FontSize { Val = "18" }),
                                new Text(val)))));
                    }
                    table.AppendChild(tr);
                    alt = !alt;
                }
                body.AppendChild(table);

                body.AppendChild(new Paragraph(
                    new ParagraphProperties(new SpacingBetweenLines { Before = "300" }),
                    new Run(
                        new RunProperties(new Italic(), new Color { Val = "888888" }),
                        new Text("Всего записей: " + dt.Rows.Count))));

                main.Document.Save();
            }
        }

        private T MkBorder<T>() where T : BorderType, new()
        {
            T b = new T();
            b.Val   = BorderValues.Single;
            b.Size  = 4;
            b.Color = "CBD2DC";
            return b;
        }

        private void GenerateSummaryWord(string path)
        {
            DataTable stats = DB.GetDashboardStats();
            DataTable ops   = DB.GetTransactions(DpFrom.SelectedDate, DpTo.SelectedDate);
            DataTable low   = DB.GetLowStock();

            using (WordprocessingDocument doc =
                   WordprocessingDocument.Create(path, WordprocessingDocumentType.Document))
            {
                MainDocumentPart main = doc.AddMainDocumentPart();
                main.Document = new Document();
                Body body = main.Document.AppendChild(new Body());

                body.AppendChild(MkHdr("Сводный отчёт — СтройСклад", "1B5E9E", "36"));
                body.AppendChild(MkPar("Период: " + FormatPeriod() +
                    "  ·  Сформирован: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"), "888888", "20"));
                body.AppendChild(new Paragraph());

                body.AppendChild(MkHdr("Ключевые показатели", "1A1A2E", "28"));
                if (stats.Rows.Count > 0)
                {
                    DataRow r = stats.Rows[0];
                    body.AppendChild(MkPar("Материалов на складе: "     + r["TotalMaterials"],  "333333", "22"));
                    body.AppendChild(MkPar("Позиций с низким запасом: " + r["LowStockCount"],   "C62828", "22"));
                    body.AppendChild(MkPar("Активных проектов: "        + r["ActiveProjects"],  "2E7D32", "22"));
                    body.AppendChild(MkPar("Операций сегодня: "         + r["TodayOps"],        "FF8C00", "22"));
                    body.AppendChild(MkPar("Получено за месяц: " +
                        Convert.ToDecimal(r["MonthReceived"]).ToString("N0") + " ₽", "2E7D32", "22"));
                    body.AppendChild(MkPar("Выдано за месяц: " +
                        Convert.ToDecimal(r["MonthIssued"]).ToString("N0") + " ₽",   "C62828", "22"));
                }

                body.AppendChild(new Paragraph());
                body.AppendChild(MkHdr("Операции за период (" + ops.Rows.Count + " шт.)", "1A1A2E", "28"));
                AppendWordTable(body,
                    new[] { "Дата", "Тип", "Материал", "Кол-во", "Сумма" },
                    new[] { "TransactionDate", "TransactionType", "Material", "Quantity", "TotalCost" },
                    ops);

                body.AppendChild(new Paragraph());
                body.AppendChild(MkHdr("Позиции с низким запасом (" + low.Rows.Count + " шт.)", "C62828", "28"));
                AppendWordTable(body,
                    new[] { "Материал", "Остаток", "Минимум", "Ед.", "Место" },
                    new[] { "MaterialName", "CurrentStock", "MinStock", "Unit", "Location" },
                    low);

                main.Document.Save();
            }
        }

        private Paragraph MkHdr(string t, string c, string s)
            => new Paragraph(
                new ParagraphProperties(new SpacingBetweenLines { Before = "200", After = "100" }),
                new Run(new RunProperties(new Bold(), new Color { Val = c }, new FontSize { Val = s }), new Text(t)));

        private Paragraph MkPar(string t, string c, string s)
            => new Paragraph(
                new ParagraphProperties(new SpacingBetweenLines { After = "80" }),
                new Run(new RunProperties(new Color { Val = c }, new FontSize { Val = s }), new Text(t)));

        private void AppendWordTable(Body body, string[] headers, string[] fields, DataTable dt)
        {
            Table table = new Table();
            table.AppendChild(new TableProperties(
                new TableBorders(
                    MkBorder<TopBorder>(), MkBorder<BottomBorder>(),
                    MkBorder<LeftBorder>(), MkBorder<RightBorder>(),
                    MkBorder<InsideHorizontalBorder>(), MkBorder<InsideVerticalBorder>()),
                new TableWidth { Width = "9360", Type = TableWidthUnitValues.Dxa }));

            TableRow hdr = new TableRow();
            foreach (string h in headers)
                hdr.AppendChild(new TableCell(
                    new TableCellProperties(new Shading { Fill = "1B5E9E", Val = ShadingPatternValues.Clear }),
                    new Paragraph(new Run(
                        new RunProperties(new Bold(), new Color { Val = "FFFFFF" }, new FontSize { Val = "18" }),
                        new Text(h)))));
            table.AppendChild(hdr);

            bool alt = false;
            foreach (DataRow row in dt.Rows)
            {
                TableRow tr   = new TableRow();
                string   fill = alt ? "F0F4FA" : "FFFFFF";
                foreach (string f in fields)
                {
                    string val = "";
                    if (dt.Columns.Contains(f))
                    {
                        object v = row[f];
                        val = (v is DateTime) ? ((DateTime)v).ToString("dd.MM.yyyy") :
                              v == DBNull.Value ? "" : v.ToString();
                    }
                    tr.AppendChild(new TableCell(
                        new TableCellProperties(new Shading { Fill = fill, Val = ShadingPatternValues.Clear }),
                        new Paragraph(new Run(new RunProperties(new FontSize { Val = "18" }), new Text(val)))));
                }
                table.AppendChild(tr);
                alt = !alt;
            }
            body.AppendChild(table);
        }

        // ════════════════════════════════════════════════════════════
        //  Генерация Excel
        // ════════════════════════════════════════════════════════════

        private void GenerateExcel(string path, string sheetName,
            string[] headers, string[] fields, DataTable dt)
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                IXLWorksheet ws = wb.Worksheets.Add(sheetName);

                ws.Cell(1, 1).Value = sheetName + " — СтройСклад";
                ws.Cell(1, 1).Style.Font.Bold      = true;
                ws.Cell(1, 1).Style.Font.FontSize  = 14;
                ws.Cell(1, 1).Style.Font.FontColor = XLColor.FromHtml("#1B5E9E");
                ws.Range(1, 1, 1, headers.Length).Merge();

                ws.Cell(2, 1).Value = "Сформирован: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm")
                    + "  ·  " + FormatPeriod();
                ws.Cell(2, 1).Style.Font.FontColor = XLColor.Gray;
                ws.Cell(2, 1).Style.Font.FontSize  = 10;
                ws.Range(2, 1, 2, headers.Length).Merge();

                for (int i = 0; i < headers.Length; i++)
                {
                    var cell = ws.Cell(4, i + 1);
                    cell.Value = headers[i];
                    cell.Style.Font.Bold               = true;
                    cell.Style.Font.FontColor          = XLColor.White;
                    cell.Style.Fill.BackgroundColor    = XLColor.FromHtml("#1B5E9E");
                    cell.Style.Alignment.Horizontal    = XLAlignmentHorizontalValues.Center;
                    cell.Style.Border.OutsideBorder    = XLBorderStyleValues.Thin;
                    cell.Style.Border.OutsideBorderColor = XLColor.FromHtml("#CBD2DC");
                }

                int rowNum = 5;
                bool alt   = false;
                foreach (DataRow row in dt.Rows)
                {
                    for (int i = 0; i < fields.Length; i++)
                    {
                        var cell = ws.Cell(rowNum, i + 1);
                        if (dt.Columns.Contains(fields[i]))
                        {
                            object v = row[fields[i]];
                            if (v == DBNull.Value || v == null)
                                cell.Value = "";
                            else if (v is DateTime)
                                cell.Value = ((DateTime)v).ToString("dd.MM.yyyy HH:mm");
                            else if (v is decimal || v is double || v is float || v is int)
                            { cell.Value = Convert.ToDouble(v); cell.Style.NumberFormat.Format = "#,##0.00"; }
                            else
                                cell.Value = v.ToString();
                        }
                        cell.Style.Fill.BackgroundColor    = alt ? XLColor.FromHtml("#F0F4FA") : XLColor.White;
                        cell.Style.Border.OutsideBorder    = XLBorderStyleValues.Thin;
                        cell.Style.Border.OutsideBorderColor = XLColor.FromHtml("#E8ECF0");
                    }
                    rowNum++;
                    alt = !alt;
                }

                ws.Cell(rowNum + 1, 1).Value = "Всего записей: " + dt.Rows.Count;
                ws.Cell(rowNum + 1, 1).Style.Font.Italic    = true;
                ws.Cell(rowNum + 1, 1).Style.Font.FontColor = XLColor.Gray;

                ws.Columns().AdjustToContents();
                foreach (IXLColumn col in ws.Columns())
                    if (col.Width < 10) col.Width = 10;
                ws.SheetView.FreezeRows(4);

                wb.SaveAs(path);
            }
        }

        private void GenerateSummaryExcel(string path)
        {
            DataTable stats = DB.GetDashboardStats();
            DataTable stock = DB.GetStockLevels();
            DataTable ops   = DB.GetTransactions(DpFrom.SelectedDate, DpTo.SelectedDate);
            DataTable low   = DB.GetLowStock();

            using (XLWorkbook wb = new XLWorkbook())
            {
                // Лист 1: KPI
                var wsKpi = wb.Worksheets.Add("Сводка");
                wsKpi.Cell(1, 1).Value = "Сводный отчёт — СтройСклад";
                wsKpi.Cell(1, 1).Style.Font.Bold      = true;
                wsKpi.Cell(1, 1).Style.Font.FontSize  = 16;
                wsKpi.Cell(1, 1).Style.Font.FontColor = XLColor.FromHtml("#1B5E9E");
                wsKpi.Range(1, 1, 1, 3).Merge();
                wsKpi.Cell(2, 1).Value = "Период: " + FormatPeriod()
                    + "  ·  " + DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                wsKpi.Cell(2, 1).Style.Font.FontColor = XLColor.Gray;
                wsKpi.Range(2, 1, 2, 3).Merge();

                if (stats.Rows.Count > 0)
                {
                    DataRow r = stats.Rows[0]; int row = 4;
                    KpiRow(wsKpi, row++, "Материалов на складе",      r["TotalMaterials"].ToString(),  "#1B5E9E");
                    KpiRow(wsKpi, row++, "Позиций с низким запасом",   r["LowStockCount"].ToString(),   "#C62828");
                    KpiRow(wsKpi, row++, "Активных проектов",          r["ActiveProjects"].ToString(),  "#2E7D32");
                    KpiRow(wsKpi, row++, "Операций сегодня",           r["TodayOps"].ToString(),        "#FF8C00");
                    KpiRow(wsKpi, row++, "Получено за месяц (₽)", Convert.ToDecimal(r["MonthReceived"]).ToString("N0"), "#2E7D32");
                    KpiRow(wsKpi, row++, "Выдано за месяц (₽)",   Convert.ToDecimal(r["MonthIssued"]).ToString("N0"),   "#C62828");
                }
                wsKpi.Columns().AdjustToContents();

                // Лист 2–4
                FillSheet(wb.Worksheets.Add("Остатки"), "Остатки склада",
                    new[] { "Материал","Категория","Артикул","Остаток","Минимум","Ед.","Место","Статус" },
                    new[] { "MaterialName","Category","ArticleNumber","CurrentStock","MinStock","Unit","Location","StockStatus" },
                    stock);

                FillSheet(wb.Worksheets.Add("Операции"), "Журнал операций — " + FormatPeriod(),
                    new[] { "Дата","Тип","Материал","Кол-во","Ед.","Цена","Сумма","Поставщик","Объект" },
                    new[] { "TransactionDate","TransactionType","Material","Quantity","Unit","UnitPrice","TotalCost","Supplier","Project" },
                    ops);

                FillSheet(wb.Worksheets.Add("Низкий запас"), "Требуют пополнения",
                    new[] { "Материал","Категория","Остаток","Минимум","Ед.","Место" },
                    new[] { "MaterialName","Category","CurrentStock","MinStock","Unit","Location" },
                    low);

                wb.SaveAs(path);
            }
        }

        private void KpiRow(IXLWorksheet ws, int row, string label, string val, string color)
        {
            ws.Cell(row, 1).Value = label;
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 2).Value = val;
            ws.Cell(row, 2).Style.Font.Bold      = true;
            ws.Cell(row, 2).Style.Font.FontSize  = 14;
            ws.Cell(row, 2).Style.Font.FontColor = XLColor.FromHtml(color);
        }

        private void FillSheet(IXLWorksheet ws, string title,
            string[] headers, string[] fields, DataTable dt)
        {
            ws.Cell(1, 1).Value = title;
            ws.Cell(1, 1).Style.Font.Bold      = true;
            ws.Cell(1, 1).Style.Font.FontSize  = 13;
            ws.Cell(1, 1).Style.Font.FontColor = XLColor.FromHtml("#1B5E9E");
            ws.Range(1, 1, 1, headers.Length).Merge();

            for (int i = 0; i < headers.Length; i++)
            {
                var cell = ws.Cell(3, i + 1);
                cell.Value = headers[i];
                cell.Style.Font.Bold            = true;
                cell.Style.Font.FontColor       = XLColor.White;
                cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#1B5E9E");
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            }

            int rowNum = 4; bool alt = false;
            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < fields.Length; i++)
                {
                    var cell = ws.Cell(rowNum, i + 1);
                    if (dt.Columns.Contains(fields[i]))
                    {
                        object v = row[fields[i]];
                        if (v == DBNull.Value || v == null) cell.Value = "";
                        else if (v is DateTime) cell.Value = ((DateTime)v).ToString("dd.MM.yyyy HH:mm");
                        else if (v is decimal || v is double || v is float || v is int)
                        { cell.Value = Convert.ToDouble(v); cell.Style.NumberFormat.Format = "#,##0.##"; }
                        else cell.Value = v.ToString();
                    }
                    cell.Style.Fill.BackgroundColor = alt ? XLColor.FromHtml("#F0F4FA") : XLColor.White;
                    cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    cell.Style.Border.OutsideBorderColor = XLColor.FromHtml("#E8ECF0");
                }
                rowNum++; alt = !alt;
            }
            ws.Columns().AdjustToContents();
            ws.SheetView.FreezeRows(3);
        }

        // ════════════════════════════════════════════════════════════
        //  Вспомогательные методы
        // ════════════════════════════════════════════════════════════

        private string GetSavePath(string name, string ext)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName         = name + "_" + DateTime.Now.ToString("yyyyMMdd"),
                DefaultExt       = "." + ext,
                Filter           = ext == "docx"
                    ? "Word документ (*.docx)|*.docx"
                    : "Excel книга (*.xlsx)|*.xlsx",
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            };
            return dlg.ShowDialog() == true ? dlg.FileName : null;
        }

        private void ShowReportDone(string path)
        {
            TxtReportStatus.Text          = "✔  Отчёт сохранён: " + path;
            ReportStatusBorder.Visibility = Visibility.Visible;

            if (MessageBox.Show("Отчёт успешно создан!\n\nОткрыть файл?", "Готово",
                    MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
                System.Diagnostics.Process.Start(path);
        }

        private string FormatPeriod()
        {
            string from = DpFrom.SelectedDate?.ToString("dd.MM.yyyy") ?? "—";
            string to   = DpTo.SelectedDate?.ToString("dd.MM.yyyy")   ?? "—";
            return from + " — " + to;
        }

        private static void Err(Exception ex)
            => MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

        private static void Info(string msg)
            => MessageBox.Show(msg, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
    }
}
